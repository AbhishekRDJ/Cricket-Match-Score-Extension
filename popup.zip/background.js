// background.js
chrome.runtime.onInstalled.addListener(function () {
    console.log("Match Search Extension installed.");
});
